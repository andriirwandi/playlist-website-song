let fillbar = document.querySelector(".fill");
let audios = ["lagu3000.mp3", "laguMemories.mp3", "laguSenorita.mp3"];
let covers = ["Asset/3000.jpg", "Asset/memories.jpg", "Asset/senorita.jpg"];
let currentTime = document.querySelector(".timeSong");

// Create An Object Of Audio

let audio = new Audio();
let currentSong = 0;
  
// whenever the window load, song should play automaticly

window.onload = playSong;

// let's play the song by this function whenever window load

function playSong() {
  audio.src = audios[currentSong];
  audio.play();
}

function togglePlayPause() {
  if (audio.paused) {
    audio.play();
    let playBtn = document.querySelector(".playPause");
    playBtn.innerHTML = '<i class="fa fa-pause"></i>';
    playBtn.style.paddingLeft = "30px";
  } else {
    audio.pause();
    playBtn = document.querySelector(".playPause");
    playBtn.innerHTML = '<i class="fa fa-play"></i>';
    playBtn.style.paddingLeft = "33px";
  }
}

// Now let's make dynamic the fillbar

audio.addEventListener("timeupdate", function() {
  let position = audio.currentTime / audio.duration;
  fillbar.style.width = position * 100 + "%";
});